from django.contrib import admin

from .models import Rent, Val


admin.site.register(Rent)
admin.site.register(Val)