from django.contrib import admin

from .models import SwapTransaction


admin.site.register(SwapTransaction)