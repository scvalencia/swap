from django.contrib import admin

from .models import Solicitude


admin.site.register(Solicitude)