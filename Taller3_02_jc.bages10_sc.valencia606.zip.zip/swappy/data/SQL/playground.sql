SELECT table_name
FROM user_tables;

SELECT * FROM passive;

SELECT * FROM genericuser;