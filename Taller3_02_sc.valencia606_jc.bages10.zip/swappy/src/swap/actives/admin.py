from django.contrib import admin

from .models import Active


admin.site.register(Active)