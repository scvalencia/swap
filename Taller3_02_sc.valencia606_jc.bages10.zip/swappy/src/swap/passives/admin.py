from django.contrib import admin

from .models import Passive


admin.site.register(Passive)