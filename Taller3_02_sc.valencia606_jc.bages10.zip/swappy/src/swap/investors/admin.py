from django.contrib import admin

from .models import Investor


admin.site.register(Investor)