from django.contrib import admin

from .models import Offerant


admin.site.register(Offerant)