from django.contrib import admin

from .models import Portfolio, PortfolioVal


admin.site.register(Portfolio)
admin.site.register(PortfolioVal)